from sklearn.feature_extraction.text import CountVectorizer
from sklearn.ensemble import RandomForestClassifier
from KaggleWord2VecUtility import KaggleWord2VecUtility
import pickle
import nltk
import numpy as np
#nltk.download('stopwords')

model_1 = 'finalized_model_25trees_5categories.sav'
vicc = 'vectorizer.sav'
#model_2 = "finalized_model_25trees_5categories.sav"
port = open(model_1, 'rb')
vic = open(vicc, 'rb')
model = pickle.load(port)
vectorizer = pickle.load(vic)

utterance="I am very bad"



clean = []



clean.append(" ".join(KaggleWord2VecUtility.review_to_wordlist(utterance, True)))

features = vectorizer.transform(clean)
np.asarray(features)
    # Use the random forest to make sentiment label predictions
print ("Predicting sentiment...\n")
result = model.predict(features)



print (result)